package lab;

public class Book extends WrittenItem {

	Book(String t, int i, int c) {
		super(t, i, c);
	}
	
	@Override
	public void setAuthor(String a) {
		super.setAuthor(a);
	}
	
	@Override
	public String getAuthor() {
		return super.getAuthor();
	}
}
