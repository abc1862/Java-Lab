package lab;

public class Video extends MediaItem {
	
	Video(String t, int i, int c) {
		super(t, i, c);
	}
	
	private String director;
	private String genre;
	private int year;
	
	@Override
	public void setRuntime(int rt) {
		super.setRuntime(rt);
	}
	
	@Override
	public int getRuntime() {
		return super.getRuntime();
	}
	
	public void setDirector(String d) {
		this.director = d;
	}
	
	public void setGenre(String g) {
		this.genre = g;
	}
	
	public void setYear(int y) {
		this.year = y;
	}
	
	public String getDirector() {
		return director;
	}
	
	public String getGenre() {
		return genre;
	}
	
	public int getYear() {
		return year;
	}

}
