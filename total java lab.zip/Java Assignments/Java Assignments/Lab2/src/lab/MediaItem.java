package lab;

public abstract class MediaItem extends Item {

	private int runtime;
	
	MediaItem(String t, int i, int c) {
		super(t, i, c);
	}
	
	public void setRuntime(int rt) {
		this.runtime = rt;
	}
	
	public int getRuntime() {
		return this.runtime;
	}
}
