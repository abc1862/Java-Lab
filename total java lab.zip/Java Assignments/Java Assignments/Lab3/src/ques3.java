import java.util.Scanner;


public class ques3 {
	void sortfunc(int n,int arr[]){
		int r,x;
		int rem=0;
		for(int i=0;i<n;i++){
			rem=0;
			x=arr[i];
			while(x!=0){
				r=x%10;
				rem=rem*10+r;
				x=x/10;
			}
			arr[i]=rem;
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		int n;
		System.out.println("Enter number of elements:");
		n=s.nextInt();
		int arr[]=new int[n];
		System.out.println("Enter elements:");
		for(int i=0;i<n;i++){
			arr[i]=s.nextInt();
		}
		ques3 q=new ques3();
		q.sortfunc(n,arr);
		
		for(int i=0;i<n;i++){
			System.out.println(arr[i]);
		}
	}

}
