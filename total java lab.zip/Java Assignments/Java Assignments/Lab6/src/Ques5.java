import java.io.*;
import java.util.Scanner;
public class Ques5 {

	public static boolean check(String s){
		String s1=s.toLowerCase();
		for(int i=1;i<s1.length();i++){
			if(s1.charAt(i)>s1.charAt(i-1)){
				continue;
			}
			else{
				return false;
			}
		}
		return true;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the string");
		String s=sc.next();
		if(check(s))
			System.out.println("It is a positive string");
		else
			System.out.println("Not a positive string");
	}

}
