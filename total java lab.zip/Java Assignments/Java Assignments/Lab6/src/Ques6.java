import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;


public class Ques6 {

	public static void difference(String s){
		String ar[]=s.split(" ",4);
		int y=Integer.parseInt(ar[0]);
		int m=Integer.parseInt(ar[1]);
		int d=Integer.parseInt(ar[2]);
		
		LocalDate now=LocalDate.now();
		LocalDate pdate=LocalDate.of(y,m,d);
		
		Period diff=Period.between(pdate,now);
		System.out.printf("\n Difference is %d years, %d months , %d days old \n \n ",diff.getYears(),diff.getMonths(),diff.getDays());
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter any date in format 'yyyy mm dd'");
		String s=sc.nextLine();
		difference(s);
		
	}

}
