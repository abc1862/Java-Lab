import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class Ques3 {
	Scanner sc=new Scanner(System.in);
	void createFile(){
		byte b[];
		String s = new String();
		try{
			FileOutputStream out=new FileOutputStream("abc.txt");
			
			
			while(true){
				System.out.println("enter");
				s=sc.nextLine();
				if(s.equals("quit"))
				{
					
					break;
				}
				b=s.getBytes();
				out.write(b);
				out.write('\n');
			}
			out.close();
			
		}catch(FileNotFoundException e){
			System.out.println(e);
		}catch(IOException e){
			System.out.println(e);
		}
		System.out.println("file created");
	}
	void countLines(){
		int countline=0;
		int countcharacter=0;
		int countwords=0;
		try {
			FileInputStream fin= new FileInputStream("abc.txt");
			int s;
			
			while((s=fin.read())!= -1){
				countcharacter++;
				if(s == '\n') {countline++;}
				if(s==' ' || s=='\n'){
				countcharacter--;}
				if(s==' ' || s=='\n') countwords++;
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
		}
		System.out.println("The number of lines are "+countline);
		System.out.println("The number of characters are "+countcharacter);
		System.out.println("The number of words are "+countwords);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ques3 c=new Ques3();
		c.createFile();
		c.countLines();
	}

}
