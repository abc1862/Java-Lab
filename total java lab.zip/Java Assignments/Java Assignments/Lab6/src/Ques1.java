import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.StringTokenizer;


public class Ques1 {
	
	void writeFile(){
		try{
			FileWriter f=new FileWriter("abc.txt");
			String st="10 20 30 40 50";
			f.write(st);
			f.close();
		}catch(FileNotFoundException e){
			e.printStackTrace();
		}catch(IOException e){
			e.printStackTrace();
		}
		System.out.println("File created");
	}
	void readFile() throws IOException{
		BufferedReader b=null;
		FileReader fr=new FileReader("abc.txt");
		try {
		b=new BufferedReader(fr);
		String line=b.readLine();
		int sum=0;
		while(line!=null){
			StringTokenizer st1 = new StringTokenizer(line, " ");
			while (st1.hasMoreTokens()) 
				{
				String s =st1.nextToken();
				System.out.println(s);
				sum+=Integer.parseInt(s);
				}
			line=b.readLine();
		}
		
		System.out.println(sum);
		
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
 public static void main(String[] args) throws IOException {
	Ques1 q=new Ques1();
	q.writeFile();
	q.readFile();
}
}
