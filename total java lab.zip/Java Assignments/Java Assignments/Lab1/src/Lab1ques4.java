import java.util.Scanner;
import java.lang.Math; 

public class Lab1ques4 {
	boolean checkNumber(int n){
		for(int i=1;i<=n;i=i*2){
			if(i==n){
				return true;
			}
		}
		return false;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n;
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the number");
		n=s.nextInt();
		Lab1ques4 l=new Lab1ques4();
		boolean b=l.checkNumber(n);
		if(b==true){
			System.out.println("Yes");
		}else{
			System.out.println("No");
		}
		s.close();
	}

}
