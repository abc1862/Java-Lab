import java.util.Scanner;

class myexception extends Exception{
	String f(){
		return "enter NAME";
	}
}

public class Ques4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter First Name");
		String fname=sc.nextLine();
		System.out.println("Enter Last Name");
		String lname=sc.nextLine();
		
		try{
			if(fname.isEmpty() || lname.isEmpty()){
				throw new myexception();}
			else{
			System.out.println("Name:"+fname+" "+lname);
			}
		}catch(myexception e){
			System.out.println(e.f());
		}
		sc.close();
	}

}
