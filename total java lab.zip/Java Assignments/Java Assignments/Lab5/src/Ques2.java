import java.util.Scanner;


public class Ques2 {
	static void fibonacci(int n){
		int a=1,b=1;
		int c=0;
//		System.out.println(n);
		System.out.print(a+" " +b +" ");
		while(c<n){
			c=a+b;
			a=b;
			b=c;
			System.out.print(c +" ");
		}
	}
	static int recursion_fibonacci(int n){
		if(n==0)
			return 1;
		if(n==1 || n==2)
			return 1;
		return recursion_fibonacci(n-1)+recursion_fibonacci(n-2);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number");
		int n=sc.nextInt();
//		System.out.println(n);
		fibonacci(n);
		System.out.println();
		for(int i=1;i<=n;i++){
			System.out.print(recursion_fibonacci(i)+" ");
		}
		sc.close();
	}

}
