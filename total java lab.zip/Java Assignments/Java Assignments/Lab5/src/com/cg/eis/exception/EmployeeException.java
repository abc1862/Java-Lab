package com.cg.eis.exception;

public class EmployeeException extends Exception{
 String sal(){
	 return "Salary is less than 3000";
 }
}
