package com.cg.eis.exception;

import java.util.Scanner;
import com.cg.eis.exception.EmployeeException;
public class Employee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your Salary");
		int s=sc.nextInt();
		try{
			if(s<3000)
				throw new EmployeeException();
			
		}catch(EmployeeException e){
			System.out.println(e.sal());
		}
		

	}

}
