import java.util.Scanner;


public class Ques3 {

	static void primeNumbers(int n){
		int f=1;
		for(int i=2;i<n;i++){
			for(int j=2;j<(i/2)+1;j++){
				if(i%j==0){
					f=0;
					break;
				}
			}
			if(f==1)
				System.out.print(i+" ");
			f=1;
			
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the number");
		int n=sc.nextInt();
		primeNumbers(n);
		
	}

}
