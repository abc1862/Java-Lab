import java.util.Scanner;

class myexception1 extends Exception{
	String f(){
		return "Age of a person should be above 15";
	}
}

public class Ques5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter age");
		int age=sc.nextInt();
		try{
			if(age<15){
				throw new myexception1();}
			else{
			System.out.println("Age:"+age);
			}
		}catch(myexception1 e){
			System.out.println(e.f());
		}
		sc.close();
	}

}
