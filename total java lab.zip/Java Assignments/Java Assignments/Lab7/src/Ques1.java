import java.util.*;
import java.util.Map.Entry;


public class Ques1 {

	public static ArrayList<String> getValue(HashMap<Integer,String> hm){
		
		ArrayList<String> al=new ArrayList<String>();
		for(Entry<Integer,String> e:hm.entrySet()){
			al.add(e.getValue());
		}
		Collections.sort(al);
		return al;
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of values to be sorted");
		int n=sc.nextInt();
		HashMap<Integer,String> hm=new HashMap<Integer,String>();
		String s;
		int id;
		for(int i=0;i<n;i++){
			System.out.println("Enter the value");
			id=sc.nextInt();
			s=sc.next();
			hm.put(id,s);
		}
		ArrayList<String> al=new ArrayList<String>();
		al=getValue(hm);
		System.out.println(al);

	}

}
