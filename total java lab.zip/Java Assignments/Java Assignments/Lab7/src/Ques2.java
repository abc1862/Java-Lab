import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Scanner;


public class Ques2 {
	
	public static LinkedHashMap<Character,Integer> countCharacter(String s){
		LinkedHashMap<Character,Integer> hm=new LinkedHashMap<Character,Integer>();
		for(int i=0;i<s.length();i++){
			Character ch=s.charAt(i);
			if(hm.containsKey(ch))
				hm.put(ch,hm.get(ch)+1);
			else{
				hm.put(s.charAt(i),1);
			}
		}
		return hm;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the string");
		String s=sc.next();
		LinkedHashMap<Character,Integer> hm=new LinkedHashMap<Character,Integer>();
		hm=countCharacter(s);
		System.out.println(hm);
	}

}
