import java.util.*;
import java.util.Map.Entry;
public class Ques3 {

	public static HashMap<Integer,Integer> getSquares(int arr[]){
		HashMap<Integer,Integer> mp=new HashMap<Integer,Integer>();
		int x;
		for(int i=0;i<arr.length;i++){
			x=arr[i];
			mp.put(x,x*x);
		}
		return mp;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of elements  ");
		int n=sc.nextInt();
		int arr[]=new int[n];
		System.out.println("enter values");
		for(int i=0;i<n;i++){
			arr[i]=sc.nextInt();
		}
		HashMap<Integer,Integer> mp=new HashMap<Integer,Integer>();
		mp=getSquares(arr);
		for(Entry<Integer,Integer> e:mp.entrySet()){
			System.out.print(e.getKey() + " ");
			System.out.println(e.getValue() +" ");
		}
	}

}
