package lab;

public abstract class Item {
	
	private String title;
	private int id;
	private int copies;
	
	Item(String t, int i, int c) {
		this.title = t;
		this.id = i;
		this.copies = c;
	}
	
	public void setTitle(String t) {
		this.title = t;
	}
	
	public void setId(int i) {
		this.id = i;
	}
	
	public void setCopies(int c) {
		this.copies = c;
	}
	
	public String getTitle() {
		return this.title;
	}
	
	public int getId() {
		return this.id;
	}
	
	public int getCopies() {
		return this.copies;
	}
	
	@Override
	public String toString() {
		return "Item [Identification number: "+id+" , Title: "+title+" , Copies: "+copies+".";
	}
}
