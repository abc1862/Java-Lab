package lab;

public class JournalPaper extends WrittenItem {
	
	private int date;
	
	JournalPaper(String t, int i, int c) {
		super(t, i, c);
	}
	
	public void setDate(int d) {
		this.date = d;
	}
	
	public int getDate() {
		return this.date;
	}
	
	@Override
	public void setAuthor(String a) {
		super.setAuthor(a);
	}
	
	@Override
	public String getAuthor() {
		return super.getAuthor();
	}	
}
