package lab;

import java.util.Scanner;

public class Client {
	
	static Scanner sc = new Scanner(System.in);
	
	Book book;
	JournalPaper journal;
	Video video;
	CD cd;
	
	void setBookData(String title, int id, int copies) {
		book = new Book(title, id, copies);
		System.out.println("Enter author name: ");
		book.setAuthor(sc.next());
	}
	
	void getBookData() {
		System.out.println("Book Title: "+ book.getTitle());
		System.out.println("Book Id: "+ book.getId());
		System.out.println("No. of copies: "+ book.getCopies());
		System.out.println("Author name: "+ book.getAuthor());
	}
	
	void setJournalData(String title, int id, int copies) {
		journal = new JournalPaper(title, id, copies);
		System.out.println("Enter author name: ");
		journal.setAuthor(sc.next());
		System.out.println("Enter date: ");
		journal.setDate(sc.nextInt());
	}
	
	void getJournalData() {
		System.out.println("Journal Paper Title: "+ journal.getTitle());
		System.out.println("Journal Paper Id: "+ journal.getId());
		System.out.println("Journal Paper Copies: "+ journal.getCopies());
		System.out.println("Journal Paper Author: "+ journal.getAuthor());
		System.out.println("Journal Paper publication date: "+ journal.getDate());
	}
	
	void setVideoData(String title, int id, int copies) {
		video = new Video(title, id, copies);
		System.out.println("Enter the Runtime: ");
		video.setRuntime(sc.nextInt());
		System.out.println("Enter the Director: ");
		video.setDirector(sc.next());
		System.out.println("Enter the Genre: ");
		video.setGenre(sc.next());
		System.out.println("Enter the year: ");
		video.setYear(sc.nextInt());
	}
	
	void getVideoData() {
		System.out.println("Video Title: "+ video.getTitle());
		System.out.println("Video Id: "+ video.getId());
		System.out.println("Video Copies: "+ video.getCopies());
		System.out.println("Video Runtime: "+ video.getRuntime());
		System.out.println("Video Director: "+ video.getDirector());
		System.out.println("Video Genre: "+ video.getGenre());
		System.out.println("Video Year: "+ video.getYear());
	}
	
	void setCdData(String title, int id, int copies) {
		cd = new CD(title, id, copies);
		System.out.println("Enter the Runtime: ");
		cd.setRuntime(sc.nextInt());
		System.out.println("Enter the Genre: ");
		cd.setGenre(sc.next());
		System.out.println("Enter the Artist: ");
		cd.setArtist(sc.next());
	}

	void getCdData() {
		System.out.println("CD Title: "+ cd.getTitle());
		System.out.println("CD Id: "+ cd.getId());
		System.out.println("CD Copies: "+ cd.getCopies());
		System.out.println("CD Runtime: "+ cd.getRuntime());
		System.out.println("CD Genre: "+ cd.getGenre());
		System.out.println("CD Artist: "+ cd.getArtist());
	}
	
	public static void main(String[] args) {
		Client c = new Client();
		
		System.out.println("Enter your choice: ");
		System.out.println("1. Book");
		System.out.println("2. Journal Paper");
		System.out.println("3. Video");
		System.out.println("4. CD");
		
		int n = sc.nextInt();
		sc.nextLine();
		System.out.println("Enter Title: ");
		String title = sc.nextLine();
		System.out.println("Enter ID: ");
		int id = sc.nextInt();
		System.out.println("Enter Copies: ");
		int copies = sc.nextInt();
		
		if(n==1) {
			c.setBookData(title, id, copies);
			c.getBookData();
		} else if(n==2) {
			c.setJournalData(title, id, copies);
			c.getJournalData();
		} else if(n==3) {
			c.setVideoData(title, id, copies);
			c.getVideoData();
		} else if(n==4) {
			c.setCdData(title, id, copies);
			c.getCdData();
		} else
			System.out.println("Invalid Choice");
	}

}
