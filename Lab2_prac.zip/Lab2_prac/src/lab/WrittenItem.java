package lab;

public abstract class WrittenItem extends Item {
	
	private String author;
	
	WrittenItem(String t, int i, int c) {
		super(t, i, c);
	}
	
	public void setAuthor(String a) {
		this.author = a;
	}
	
	public String getAuthor() {
		return this.author;
	}
}
