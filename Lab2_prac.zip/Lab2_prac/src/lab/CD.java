package lab;

public class CD extends MediaItem {
	
	CD(String t, int i, int c) {
		super(t, i, c);
	}
	
	private String artist;
	private String genre;
	
	@Override
	public void setRuntime(int rt) {
		super.setRuntime(rt);
	}
	
	@Override
	public int getRuntime() {
		return super.getRuntime();
	}
	
	public void setArtist(String a) {
		this.artist = a;
	}
	
	public void setGenre(String g) {
		this.genre = g;
	}
	
	public String getArtist() {
		return artist;
	}
	
	public String getGenre() {
		return genre;
	}
}
